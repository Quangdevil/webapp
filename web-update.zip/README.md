# QuangDurenOnline V20.28 fix45

Static web update.

## Version
QuangDurenOnline V20.28 fix45-fuhui-delete-in-place

## Notes
- Fix 付汇 delete: delete in-place, no full sync render, no jump to first page.
- Removes matching local backup when deleting.
- Based on fix44.
